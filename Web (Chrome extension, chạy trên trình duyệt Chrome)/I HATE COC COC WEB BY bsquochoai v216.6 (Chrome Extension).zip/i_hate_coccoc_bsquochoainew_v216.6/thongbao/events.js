﻿chrome.runtime.onMessage.addListener(
  function(req, sender, sendResponse) {
    if (req.ham == "read"){
		switch (req.t) {
			case "pause":
				chrome.tts.pause();
				break;
			case "resume":
				chrome.tts.resume()
				break;
			case "speak":
				speek(req.d)
				break;
		}
	}
	else if ( req.ham == "luutu") {
		switch (req.t) {
			case "luu":
				if (localStorage.st == null ){localStorage.st = 0}
				var st = Number(localStorage.st)
				var trungkhong = 0
				for (i = st-1; i >= st-5; i--) { //check 5 tu gan nhat xem co trung k
					if( req.c == localStorage.getItem("tc"+i) ){
						trungkhong = 1
						break;
					}
					else {trungkhong = 0}
				}
				if (req.c.toString().length <= 131 && trungkhong == 0){
					savetu(req.c, req.u)
				}
				break;
			case "lay":
				break;
		}
	}
	else if (req.ham == "downloadzingmp3"){
		var downloadoptions = {url:req.link, filename:req.name}
		chrome.downloads.download(downloadoptions, function(){})
	}
	else if (req.ham == "taixuongyoutube"){
		chrome.windows.create({
		 type: 'detached_panel',
		 url: req.u,
		 width:Math.round(screen.width*80/100),
		 height: 400,
		 left: 100,
		 top: 100
		}, function (newWindow) {});
	}
});
if (localStorage.gtngonngu == null){localStorage.gtngonngu = "vi"}
if (localStorage.batphanmem == null){localStorage.batphanmem = "1"}
if (localStorage.gender == null ) {localStorage.gender = "female"}
if (localStorage.lang == null ) {localStorage.lang = "en-US"}
if (localStorage.rate == null ) {localStorage.rate = "0.9"}
if (localStorage.volume == null ) {localStorage.volume = "1"}
if (localStorage.cddoc == null ) {localStorage.cddoc = "cddocgt"}
if (localStorage.cdnguondich == null ) {localStorage.cdnguondich = "cddichgt"}
if (localStorage.cdrechuot == null ) {localStorage.cdrechuot = "0"}

//Long live connect lấy Cài đặt nhanh bên context
chrome.runtime.onConnect.addListener(function(port) {
  console.assert(port.name == "caidatnhanh");
  port.onMessage.addListener(function(m) {
		if (m.data = "cd"){
			port.postMessage({cddoc: localStorage.cddoc, cdhighlight:localStorage.cdhighlight, cdnghedoc:localStorage.cdnghedoc, cdluutu:localStorage.cdluutu, cdhientudien:localStorage.cdhientudien, cddoctiengviet:localStorage.cddoctiengviet, gtdocngonngu:localStorage.gtdocngonngu, gttudien:localStorage.gttudien, batphanmem: localStorage.batphanmem, cdnguondich:localStorage.cdnguondich, cdrechuot: localStorage.cdrechuot});
		}
  });
});

chrome.webRequest.onBeforeRequest.addListener(
        function(details) { return {cancel: true}; },
        {urls: ["http://d1.violet.vn/ads/*","https://www.googleadservices.com/pagead/", "http://s.ad360.vn/*", "http://static.adtimaserver.vn/*", "http://rtax.criteo.com/delivery/*", "http://api.adtimaserver.vn/*","http://asianmedia.com/GAAN/www/delivery/*", "*://*.googlesyndication.com/*", "*://*.adtimaserver.vn/*", "*://ad.doubleclick.net/*", "*://*.revsci.net/*", "*://adi.vcmedia.vn/*", "*://admicro1.vcmedia.vn/*","*://*.g.doubleclick.net/*", "*://*.polyad.net/*","*://s.tuoitre.vn/*", "*://stc.id.nixcdn.com/*", "*://*.chitika.net/*","*://*.adk2x.com/*","*://*.2xbpub.com/*","*://*.ad131m.com/*","*://*.vetv.vn/*","*://vetv.vn/*"]},
        ["blocking"]);
chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf(".mp4") > 0 || details.url.indexOf(".flv") > 0){
				return {redirectUrl: "https://dl-web.dropbox.com/get/Saves/small%20(online-video-cutter.com).mp4?_subject_uid=65691686&w=AACzJcKpkXHYfbHHaSNa2dHINJ-q1xigNnvREMJwcq7Kaw&dl=1"}
			}
	},
	{urls: ["*://*.blueseed.tv/*", "*://*.serving-sys.com/*","*://*.videologygroup.com/*", "*://*.adnetwork.vn/*"]},
	["blocking"])

//http://media.adnetwork.vn/banner/video/2015/06/1435571160.mp4

chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf("/js/game.js") > 0){
				return {redirectUrl: "https://i-hate-coccoc-bsquochoai.googlecode.com/git/suaScript/tienganh123gamevip.js"}
			}
			if(details.url.indexOf("/dungchung/function.js") > 0){
				return {redirectUrl: "https://i-hate-coccoc-bsquochoai.googlecode.com/git/suaScript/tienganh123function.js"}
			}
			if(details.url.indexOf("/js/audio_ddn.js") > 0){
				return {redirectUrl: "https://i-hate-coccoc-bsquochoai.googlecode.com/git/suaScript/tienganh123audio_ddn.js"}
			}
			if(details.url.indexOf("/js/jquery_ready.js") > 0){
				return {redirectUrl: "https://i-hate-coccoc-bsquochoai.googlecode.com/git/suaScript/tienganh123jquery_ready.js"}
			}
			if(details.url.indexOf("/js/libs_audio.js") > 0){
				return {redirectUrl: "https://i-hate-coccoc-bsquochoai.googlecode.com/git/suaScript/ta123libs_audio.js"}
			}
			if(details.url.indexOf("/olympic/js/action.js") > 0){
				return {redirectUrl: "https://i-hate-coccoc-bsquochoai.googlecode.com/git/suaScript/ta123olympic_action.js"}
			}
	},
	{urls: ["*://*.tienganh123.com/*"]},
	["blocking"]) 

 chrome.webRequest.onBeforeSendHeaders.addListener(
        function(details) {
			if (details.url.indexOf("translate.google.com.vn/translate_tts") > 0){
				 for (var i = 0; i < details.requestHeaders.length; ++i) {
					if (details.requestHeaders[i].name === 'Referer') {
					  details.requestHeaders[i].value = "https://translate.google.com.vn/translate_tts?ie=UTF-8&editfrom=bsquochoai.ga"
					  break;
					}
				}
          } //if details.url
			 else if (details.url.indexOf("translate.google.com/m?") > 0){
				 for (var i = 0; i < details.requestHeaders.length; ++i) {
					if (details.requestHeaders[i].name === 'Referer') {
					  details.requestHeaders[i].value = "https://translate.google.com/m?editfrom=bsquochoai.ga"
					  break;
					}
				}
			 }
          return {requestHeaders: details.requestHeaders};
        },
        {urls: ["<all_urls>"]},
        ["blocking", "requestHeaders"]);
		  
 chrome.webRequest.onHeadersReceived.addListener(function(details){
    for(var i = 0; i < details.responseHeaders.length; ++i){
        if(details.responseHeaders[i].name.toLowerCase() == 'x-frame-options'){
            details.responseHeaders[i].value = 'ALLOWALL';
			}
			if (details.url.indexOf("ionary.reference.com/browse/") > 0){
				for (var i = 0; i < details.requestHeaders.length; ++i) {
					if (details.requestHeaders[i].name === 'Access-Control-Allow-Origin') {
					  details.requestHeaders[i].value = "*"
					  break;
					}
				}
			 } else {
				details.requestHeaders[55].name = 'Access-Control-Allow-Origin'
				details.requestHeaders[55].value = "*"
			 }
		}
    return {responseHeaders:details.responseHeaders};
}, {urls: ["<all_urls>"]}, ['blocking', 'responseHeaders']);

//Command keyboard shortcut
chrome.commands.onCommand.addListener(function(cmd) {
   if (cmd == "doclai"){
		 if(localStorage.cddoc == "cddocchuan"){
				chrome.storage.local.get('tumoidoc', function (re) {
					 chrome.runtime.sendMessage({ham: "read",t:"speak", d: re.tumoidoc})
				});
			} else if(localStorage.cddoc == "cddocgt"){
				/* chrome.tabs.getCurrent(function(tab){
					chrome.tabs.executeScript(tab.id, {code:''}, function(){})
				}) */
			}
	} else if (cmd=="battatphanmem"){
		if ( localStorage.batphanmem =="1" ){
			localStorage.setItem("batphanmem","0")
			options= {
					type:"basic",
					title:"Đã tắt!",
					iconUrl:"/icon/icon128.png",
					message:"Em hãy bấm Alt+Q lần nữa để bật phần mềm."
				}
				chrome.notifications.create("tb", options,function(){})
		} else {
			localStorage.setItem("batphanmem","1")
			options= {
					type:"basic",
					title:"Đã bật!",
					iconUrl:"/icon/icon128.png",
					message:"Em hãy bấm Alt+Q lần nữa để tắt phần mềm."
				}
				chrome.notifications.create("tb", options,function(){})
			
		}
	} else if (cmd=="momaytinhcasio"){
		var w = Math.round(screen.width*80/100)
		var h =Math.round(screen.height*85/100)
		var l = Math.round((screen.width/2)-(w/2));
		var t = Math.round((screen.height/2)-(h/2));
		chrome.windows.create({
		 type: 'detached_panel',
		 url: "http://web2.0calc.com/",
		 width:w,
		 height: h,
		 left: l,
		 top: t
		}, function (newWindow) {
		});
	}
});
setInterval(function(){
	chrome.notifications.clear("tb", function(){})
},10000)
chrome.notifications.onClicked.addListener(function(nid,byuser){
	chrome.notifications.clear(nid, function(){
	})
})
var now = new Date();
var thoigianhoc = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 19, 55, 00, 0) ;
chrome.alarms.create("alarmhocanhvancungthay", {
	when: thoigianhoc.getTime(),
	periodInMinutes: 24*60*60
})
chrome.alarms.onAlarm.addListener(function(a){
	if(a.name="alarmhocanhvancungthay"){
		chrome.notifications.create("hocanhvan", {
					type:"basic",
					title:"Tới giờ HỌC ANH VĂN CÙNG THẦY!",
					iconUrl:"/icon/icon128.png",
					message:"20:00 hôm nay trên AloAlo, em hãy nhanh chóng chuẩn bị để học cùng thầy và các bạn nhen."
				},function(){})
		chrome.tts.speak("It's time to study English with thayy bs walk why, please open Alo Alo to learn at 8 o'clock!");
	}
})
function savetu(c,u){
	var st = Number(localStorage.st)
	var l =""
	if (localStorage.cddoc == "cddocgt"){ l=localStorage.gtdocngonngu }
	else { l=localStorage.lang }
	var d = new Date()
	var t = d.getTime()
	localStorage.setItem("tc"+st, c )
	localStorage.setItem("tl"+st, l )
	localStorage.setItem("tu"+st, u )
	localStorage.setItem("tt"+st, t)
	
	localStorage.setItem('st',st+1 )
}
function taowindow(url){
		var w = Math.round(screen.width*80/100)
		var h =Math.round(screen.height*85/100)
		var l = Math.round((screen.width/2)-(w/2));
		var t = Math.round((screen.height/2)-(h/2));
		chrome.windows.create({
		 type: 'detached_panel',
		 url: url,
		 width:w,
		 height: h,
		 left: l,
		 top: t
		}, function (newWindow) {
		});
}
function speek(t){
	chrome.tts.stop()
	var lang = localStorage.lang
	var gender = localStorage.gender
	var rate = Number(localStorage.rate)
	var volume = Number(localStorage.volume)
	chrome.tts.speak(t, {'gender':gender, 'lang':lang, 'rate': rate, 'volume':volume });
}
function x(x){console.log(x)}
chrome.runtime.onInstalled.addListener(function(d){
	if (d.reason == "install")
	taowindow("background-window.html")
})