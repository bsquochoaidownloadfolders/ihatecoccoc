/* $(function(){
var my = $(".calccontainer").clone()
$("body").html(my).css("display","block")
}) */