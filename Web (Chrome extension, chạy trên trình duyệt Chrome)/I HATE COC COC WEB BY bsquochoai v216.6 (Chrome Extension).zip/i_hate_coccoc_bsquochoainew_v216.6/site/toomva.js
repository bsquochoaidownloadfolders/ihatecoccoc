$(function(){
	past1 = $("head").html()
	past2 = $("body").html()
	$("head").html(past1.replace(/900/g , 9999999999999999999999999))
	$("body").html(past2.replace(/900/g , 9999999999999999999999999))
})